//
//  APIServiceManger.swift
//  JsonExample
//
//  Created by agilemac-9 on 7/24/18.
//  Copyright © 2018 agile. All rights reserved.
//

import Foundation
import Alamofire

typealias ApiCallSuccessBlock = (Bool,NSDictionary) -> Void
typealias ApiCallFailureBlock = (Bool,NSError?,NSDictionary?) -> Void
typealias APIResponseBlock = ((_ response: NSDictionary?,_ isSuccess: Bool,_ error: Error?)->())

enum CRMAPIType {
    
    case login
    case installationCounter
    
    func getEndPoint() -> String {
        switch self {
        case .login:
            return "api/seller_login"
        case .installationCounter:
            return "mapi/renewToken"
        }
    }
    
    func getAPIKey() -> [String]
    {
        switch self {
        case .login:
            return ["seller_login"]
        case .installationCounter:
            return ["installationCounter"]
        }
    }
}

class APIServiceManager: NSObject {
    
    static let shared = APIServiceManager()
    
    var baseURL = "http://180.211.99.165/rp/krishi_sagar/index.php"
    var baseURL2 = "http://180.211.99.165/rp/krishi_sagar/index.php"
    let apiRequestTimeOut = 600.0

    private func requestParams(ForAPIType apiType:CRMAPIType,WithParams paramFromController:[String:Any]) -> (apiURL:String,params:[String:String])
    {
        /* API URL */
        let apiUrl:String = "\(self.baseURL)\(apiType.getEndPoint())"
        
        /* API Parameters */
        let structuredParams = paramFromController
        
        var paramsForApi:[String:String] = [:]
        
        switch apiType {
            case .login:
                break
            default:
                break
        }
        
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: structuredParams, options: JSONSerialization.WritingOptions.prettyPrinted)
            
            if let jsonString = String.init(data: jsonData, encoding: String.Encoding.utf8) {
                
                let key:String = apiType.getAPIKey()[0]
                paramsForApi = [key:jsonString]
            }
        } catch {
            print("Failed to convert to string")
        }
        
        return (apiUrl,paramsForApi)
    }
    
    func callGetAPI(WithType apiType:CRMAPIType, Success successBlock:@escaping APIResponseBlock, Failure failureBlock:@escaping APIResponseBlock) -> Void
    {
        let apiUrl:String = "\(self.baseUR2L)\(apiType.getEndPoint())"

        print("/****************** New API Called ******************/")
        print("/* API URL : \(apiUrl)")
        print("/*******************************************************/")
        
        let manager = Alamofire.SessionManager.default
        manager.session.configuration.timeoutIntervalForRequest = apiRequestTimeOut
        
        manager.request(apiUrl, method: .get, parameters: nil, encoding: URLEncoding.default, headers: nil).responseJSON { (response) in
            
            var errorMsg:String = ""
            
            if response.error == nil
            {
                errorMsg = "nil"
            }
            else
            {
                errorMsg = "\(response.error! as NSError)"
            }
            
            switch response.result {
                
            case .success(let json):
                
                // You got Success :)
                print(json)
                // print("Response Status Code :: \(String(describing: response.response?.statusCode))")
                // print("Response Status :: \(String(describing: response.response?.description))")
                print(json)
                
                if let jsonResponse = json as? NSDictionary
                {
                    successBlock(jsonResponse, true, nil)
                }
                else
                {
                    print("Json Object is not NSDictionary : Please Check this API \(apiType.getEndPoint())")
                    successBlock(nil, true, nil)
                }
                break
                
            case .failure(let error):
                
                // You Got Failure :(
                // print("Response Status Code :: \(response.response?.statusCode)")
                let datastring = NSString(data: response.data!, encoding: String.Encoding.utf8.rawValue)
                print(datastring ?? "Test")
                failureBlock(nil,false,error)
                break
            }
        }
    }
    
    func callPostAPI(WithType apiType:CRMAPIType, WithParams params:[String:Any] = [:], Success successBlock:@escaping APIResponseBlock, Failure failureBlock:@escaping APIResponseBlock) -> Void
    {
        let apiHelpers = self.requestParams(ForAPIType: apiType, WithParams: params)
        
        print("/****************** New API Called ******************/")
        print("/* API URL : \(apiHelpers.apiURL)")
        print("/* API Params : \(apiHelpers.params)")
        print("/*******************************************************/")
        
        let manager = Alamofire.SessionManager.default
        manager.session.configuration.timeoutIntervalForRequest = apiRequestTimeOut

        manager.request(apiHelpers.apiURL, method: .post, parameters: apiHelpers.params, encoding: URLEncoding.default, headers: nil).responseJSON { (response) in
            
            var errorMsg:String = ""
            
            if response.error == nil
            {
                errorMsg = "nil"
            }
            else
            {
                errorMsg = "\(response.error! as NSError)"
            }
            
            switch response.result {
                
            case .success(let json):
                
                // You got Success :)
                print(json)
                // print("Response Status Code :: \(String(describing: response.response?.statusCode))")
                // print("Response Status :: \(String(describing: response.response?.description))")
                print(json)
                
                if let jsonResponse = json as? NSDictionary
                {
                    successBlock(jsonResponse, true, nil)
                }
                else
                {
                    print("Json Object is not NSDictionary : Please Check this API \(apiType.getEndPoint())")
                    successBlock(nil, true, nil)
                }
                break

            case .failure(let error):
                
                // You Got Failure :(
                // print("Response Status Code :: \(response.response?.statusCode)")
                let datastring = NSString(data: response.data!, encoding: String.Encoding.utf8.rawValue)
                print(datastring ?? "Test")
                failureBlock(nil,false,error)
                break
            }
        }
    }
}

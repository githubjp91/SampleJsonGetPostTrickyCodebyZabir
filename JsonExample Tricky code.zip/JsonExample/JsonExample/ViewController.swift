//
//  ViewController.swift
//  JsonExample
//
//  Created by agilemac-9 on 7/24/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        var perameters:[String:Any] = ["email":"darsh2@mailinator.com"]
        perameters["password"] = "123456"
        perameters["user_id"] = "11"

        APIServiceManager.shared.callPostAPI(WithType: .login, WithParams: perameters, Success: { (response, status, error) in
            
            print("Dic:\(String(describing: response))")
            print("Status:\(status)")
            
        }) { (response, status, error) in
            
            print("Dic:\(String(describing: response))")
            print("Status:\(status)")
        }

        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
